
clc
clear

load('channel_names.mat');
load('channel_details.mat');

% Define EZ and non-EZ
%ez_channels = ["H'1-H'2", "H'2-H'3", "H'3-H'4","H'3-H'4"];
%ez_channels_index = [10:13,30:34];

   % create vector  of channel index
	channel_names_index = [1:length(channel_names)];
   
   % determine how many elements is ten percent
	 numelements = round(1*length(channel_names_index));
   % get the randomly-selected indices
	 indices = randperm(length(channel_names_index));
	 indices = indices(1:numelements);
   % choose the subset of a you want
	 non_ez_channels_index = indices;
	 
	 
   % Remove EZ channels from index
   % electrode cost
   
	 for i=ez_channels_index
	
		 non_ez_channels_index(non_ez_channels_index == i) = [];
	
	 end
	 
	 non_ez_channels_index = unique(non_ez_channels_index); 
	 non_ez_channels = channel_names(non_ez_channels_index);

% extract
	data = load('Spikes.mat');
	temp = data.results.markers;
	
	spike_label = strings(1,length(temp));
	spike_value = zeros(1,length(temp));
	spike_position = zeros(1,length(temp));
	spike_channel = strings(1,length(temp));
	sp = 1;
	
	for i = 1 : length(temp)
		if (strcmp(temp(:, i).label, 'Spike'))
			spike_label(sp) = temp(:, i).label;
			spike_value(sp) = temp(:, i).value;
			spike_position(sp) = temp(:, i).position;
			spike_channel(sp) = cell2mat(temp(:, i).channels);
			sp = sp + 1;

		end
	end
		
	spike_label = spike_label(1:sp - 1).';
	spike_value = spike_value(1:sp - 1).';
	spike_position = spike_position(1:sp - 1).';
	spike_channel = spike_channel(1:sp - 1).';
	sp = 1;
		
	ez_spike_value1 = [];
	ez_spike_position1 = [];
	ez_spike_channel1 = [];
		
	
	%extract only EZ and non-EZ channels
	for j = 1 : length(ez_channels)
	
		for i = 1 : length(spike_label)
	
			if (strcmp(spike_channel(i), ez_channels(j)))

				ez_spike_value1 = [ez_spike_value1;spike_value(i)];
				ez_spike_position1 = [ez_spike_position1;spike_position(i)];
				ez_spike_channel1 = [ez_spike_channel1;spike_channel(i)];
		
			end
		end
	end
	
	
	non_ez_spike_value1 = [];
	non_ez_spike_position1 = [];
	non_ez_spike_channel1 = [];
	
	for j = 1 : length(non_ez_channels)
	
		for i = 1 : length(spike_label)
	
			if (strcmp(spike_channel(i), non_ez_channels(j)))

				non_ez_spike_value1 = [non_ez_spike_value1;spike_value(i)];
				non_ez_spike_position1 = [non_ez_spike_position1;spike_position(i)];
				non_ez_spike_channel1 = [non_ez_spike_channel1;spike_channel(i)];
		
			end
		end
	end
	


% Generating data set for spikes
load seeg.mat;
%plot(xx(1:10*fs));
% filter seeg for spike dataset
	

	
	for i = 1 : length(channel_names)
	
		wo = 50 / (fs / 2);
		bw = wo / 35;
		[b, a] = iirnotch(wo, bw);
		xx1(i,:) = filter(b, a,  xx(i,:));
		 
		 
		 % Butterworth Lowpass filter
		 fc_low = 70; % Cut off frequency
		 [b,a] = butter(6,fc_low/(fs/2),'low'); % Butterworth filter of order 6
		 xx1(i,:) = filtfilt(b, a, xx1(i,:));
		 
		 
		 
		  % Butterworth Highpass filter
		fc_high = 5; % Cut off frequency
		[b, a] = butter(6,fc_high/(fs/2),'high'); % Butterworth filter of order 6
		xx1(i,:) = filtfilt(b, a,  xx1(i,:));
		
	end
	
	 amplitude_ez = [];
	 pac_ez = [];
	 rms_ez = [];
	 psd_ez = [];
	 lyap_exp_ez =[];
	 corr_dim_ez = [];
	 approx_non_ent_ez = [];
	 indeg_ez = [];
	 outdeg_ez = [];
	 totaldeg_ez = [];
	 wbc_ez = [];
	
	% generate features
	for i=1:length(ez_spike_channel1)  % total detections iteration
	
	tic
	
	
		for j=1:length(channel_names)	% finding channel name index
		
			if(strcmp(ez_spike_channel1(i), channel_names(j)))
		
			ch = j;
		
			end
		end
		
		% prunnig the 1 second signa1
		
		signal = xx1(ch, round((ez_spike_position1(i) * fs) - (0.5 * fs)) : round((ez_spike_position1(i) * fs) + (0.5 * fs)));
	
		amplitude_ez = [amplitude_ez; max(signal)];
		pac_ez = [ pac_ez; phase_amplitude_coupling(signal)];
		rms_ez = [rms_ez; rms(signal)];
		psd_ez = [psd_ez; pow_spec_den(signal, fs)];
		lyap_exp_ez =[ lyap_exp_ez; lyapunovExponent(signal)];
		corr_dim_ez = [corr_dim_ez; correlationDimension(signal)];
		approx_non_ent_ez = [approx_non_ent_ez; approximateEntropy(signal)];
		
		
		
		%graph properties
		
		corr_mat = zeros(length(channel_names),length(channel_names));
		
		for kk=1:length(channel_names)
		
			for pp=1:length(channel_names)
			
			
				sig1 = xx1(kk, round((ez_spike_position1(i) * fs) - (0.5 * fs)) : round((ez_spike_position1(i) * fs) + (0.5 * fs)));
				sig2 = xx1(pp, round((ez_spike_position1(i) * fs) - (0.5 * fs)) : round((ez_spike_position1(i) * fs) + (0.5 * fs)));
			
			 if (prcorr2(sig1, sig2) > 0.6);
			 
			 
				corr_mat(kk,pp) = 1;
				
			else
				corr_mat(kk,pp) = 0;
			
			end
			end
		
		end
		
		
	
		G = digraph(corr_mat);
		t1 = indegree(G);
		t2 = outdegree(G);
		indeg_ez = [indeg_ez; t1(ch)];
		outdeg_ez = [outdeg_ez; t2(ch)];
		totaldeg_ez = [totaldeg_ez; t1(ch)+t2(ch)];
		t3 = centrality(G ,'betweenness');
		wbc_ez = [wbc_ez; t3(ch)];
		
		
	toc

	end
	
	
	% Features for non EZ
	 amplitude_non_ez = [];
	 pac_non_ez = [];
	 rms_non_ez = [];
	 psd_non_ez = [];
	 lyap_exp_non_ez =[];
	 corr_dim_non_ez = [];
	 approx_non_ent_non_ez = [];
	 indeg_non_ez = [];
	 outdeg_non_ez = [];
	 totaldeg_non_ez = [];
	 wbc_non_ez = [];
	
	% generate features
	for i=1:length(non_ez_spike_channel1)  % total detections iteration
	
		for j=1:length(channel_names)	% finding channel name index
		
			if(strcmp(non_ez_spike_channel1(i), channel_names(j)))
		
			ch = j;
		
			end
		end
		
		% prunnig the 1 second signa1
		
		signal = xx1(ch, round((non_ez_spike_position1(i) * fs) - (0.5 * fs)) : round((non_ez_spike_position1(i) * fs) + (0.5 * fs)));
	
		amplitude_non_ez = [amplitude_non_ez; max(signal)];
		pac_non_ez = [ pac_non_ez; phase_amplitude_coupling(signal)];
		rms_non_ez = [rms_non_ez; rms(signal)];
		psd_non_ez = [psd_non_ez; pow_spec_den(signal, fs)];
		lyap_exp_non_ez =[ lyap_exp_non_ez; lyapunovExponent(signal)];
		corr_dim_non_ez = [corr_dim_non_ez; correlationDimension(signal)];
		approx_non_ent_non_ez = [approx_non_ent_non_ez; approximateEntropy(signal)];
		
		
		
		%graph properties
		
		corr_mat = zeros(length(channel_names),length(channel_names));
		
		for kk=1:length(channel_names)
		
			for pp=1:length(channel_names)
			
			
				sig1 = xx1(kk, round((non_ez_spike_position1(i) * fs) - (0.5 * fs)) : round((non_ez_spike_position1(i) * fs) + (0.5 * fs)));
				sig2 = xx1(pp, round((non_ez_spike_position1(i) * fs) - (0.5 * fs)) : round((non_ez_spike_position1(i) * fs) + (0.5 * fs)));
			
			 if (prcorr2(sig1, sig2) > 0.6);
			 
			 
				corr_mat(kk,pp) = 1;
				
			else
				corr_mat(kk,pp) = 0;
			
			end
			end
		
		end
	
		G = digraph(corr_mat);
		t1 = indegree(G);
		t2 = outdegree(G);
		indeg_non_ez = [indeg_non_ez; t1(ch)];
		outdeg_non_ez = [outdeg_non_ez; t2(ch)];
		totaldeg_non_ez = [totaldeg_non_ez; t1(ch)+t2(ch)];
		t3 = centrality(G ,'betweenness');
		wbc_non_ez = [wbc_non_ez; t3(ch)];

	end
	
	
save spike_features.mat amplitude_ez pac_ez rms_ez psd_ez lyap_exp_ez corr_dim_ez approx_non_ent_ez indeg_ez outdeg_ez totaldeg_ez wbc_ez amplitude_non_ez pac_non_ez rms_non_ez psd_non_ez lyap_exp_non_ez corr_dim_non_ez approx_non_ent_non_ez indeg_non_ez outdeg_non_ez totaldeg_non_ez wbc_non_ez;
	

disp("Completed....")
	
