function xx= normalize1(xx)

	xx = (xx - min(xx)) / ( max(xx) - min(xx) );

end
