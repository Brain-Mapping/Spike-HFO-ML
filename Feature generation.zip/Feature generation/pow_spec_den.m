function [mxerr] = pow_spec_den(signal, fs)
    % Power spectral density calculation function
    % power spectral density
    t = 0:1/fs:1-1/fs;
    x = signal;
    N = length(x);
    xdft = fft(x);
    xdft = xdft(1:N/2+1);
    psdx = (1/(fs * N)) * abs(xdft).^2;
    psdx(2:end-1) = 2 * psdx(2:end-1);
    freq = 0:fs/length(x):fs / 2;
%             plot(freq, 10 * log10(psdx));
%             xlabel("Frequency (Hz)");
%             ylabel("Power / Frequency(db/Hz)");
    periodogram(x, rectwin(length(x)), length(x), fs);
    mxerr = max(psdx' - periodogram(x, rectwin(length(x)), length(x), fs));
%             disp("Power spectral density estimate " + mxerr);

    clear fs t x N xdft psdx freq;
end