

%feature generation for HFOs


clearvars -except names listing


load('channel_names.mat');
load('channel_details.mat');


%Ripples_strength = 8;
%FastRipples_strength = 8;

% Define EZ and non-EZ
%ez_channels = ["H'1-H'2", "H'2-H'3", "H'3-H'4","H'3-H'4"];
%ez_channels_index = [10:20,30:36];

% create vector  of channel index
channel_names_index = [1:length(channel_names)];
   
% determine how many elements is ten percent
numelements = round(non_ez_precen_R*length(channel_names_index));
% get the randomly-selected indices
indices = randperm(length(channel_names_index));
indices = indices(1:numelements);
% choose the subset of a you want
non_ez_channels_index = indices;
	 	 
% Remove EZ channels from index
% electrode cost
   
for i=ez_channels_index

	non_ez_channels_index(non_ez_channels_index == i) = [];

end
 
non_ez_channels_index = unique(non_ez_channels_index); 
non_ez_channels = channel_names(non_ez_channels_index);



% extract

load('HFO_Detections.mat');
%Column 1 indicates the channel in which the
% event was detected, column 2 the frequency, column 3 the start sample,
% column 4 the duration (in samples), column 5 the strenght (against which
% the threshold is compared).

Ripples_channel_index = Ripples(:,1);
Ripples_position1 = Ripples(:,3);
Ripples_strength1 = Ripples(:,5);


ez_Ripples_position1 = [];
ez_Ripples_channel1 = [];
	

%extract only EZ and non-EZ channels
for j = 1 : length(ez_channels)

	for i = 1 : length(Ripples_position1)
    
		    if (Ripples_strength1(i) > Ripples_strength)

				if (strcmp(channel_names(Ripples_channel_index(i)), ez_channels(j)))
				
					ez_Ripples_position1 = [ez_Ripples_position1;Ripples_position1(i)];
					ez_Ripples_channel1 = [ez_Ripples_channel1;channel_names(Ripples_channel_index(i))];
			
		    		end
		    
		    end
	end
end


non_ez_Ripples_position1 = [];
non_ez_Ripples_channel1 = [];
	

clear Ripples RipplesRate FastRipplesRate;
	
	
	
%extract only EZ and non-EZ channels
for j = 1 : length(non_ez_channels)

	for i = 1 : length(Ripples_position1)
    
     if (Ripples_strength1(i) > Ripples_strength)

		if (strcmp(channel_names(Ripples_channel_index(i)), non_ez_channels(j)))
		
			non_ez_Ripples_position1 = [non_ez_Ripples_position1;Ripples_position1(i)];
			non_ez_Ripples_channel1 = [non_ez_Ripples_channel1;channel_names(Ripples_channel_index(i))];
	
    end
    
    end
	end
end
	


% Generating data set for Ripples

load seeg.mat;

% filter seeg for spike dataset
	
%Defining bandpass filter
fc1 = 80; % Cut off frequency
fc2 = 250; % Cut off frequency

[b,a] = butter(6,[fc1,fc2]/(fs/2),'bandpass'); 


wo = 50 / (fs / 2);
bw = wo / 35;
[b1, a1] = iirnotch(wo, bw);

		
	
for i = 1: length(channel_names)


	xx1(i,:) = filter(b1, a1,  xx(i,:));
	xx1(i,:) = filter(b,a,xx1(i,:));

end
	

xx1(:,end:end+2100) = 0;

	
clear xx;

 amplitude_ez = [];
 pac_ez = [];
 rms_ez = [];
 psd_ez = [];
 lyap_exp_ez =[];
 corr_dim_ez = [];
 approx_non_ent_ez = [];
 indeg_ez = [];
 outdeg_ez = [];
 totaldeg_ez = [];
 wbc_ez = [];
 ch_ez =[];



% generate features
for i=1:length(ez_Ripples_channel1)-5  % total detections iteration
	
    
    tic

	
		for j=1:length(channel_names)	% finding channel name index
		
			if(strcmp(ez_Ripples_channel1(i), channel_names(j)))
		
			ch = j;
		
			end
		end
		
		% prunnig the 1 second signa1
		
		
			if (round(ez_Ripples_position1(i) + (1 * fs)) > length(xx1(1,:)))
		
					end_of_signal_ind = round(ez_Ripples_position1(i)) + 10;
					
			else
			
					end_of_signal_ind = round(ez_Ripples_position1(i)) + (1 * fs);
			
			end
		
		
		signal = xx1(ch, round((ez_Ripples_position1(i)))  : end_of_signal_ind);
	
		amplitude_ez = [amplitude_ez; max(signal)];
		pac_ez = [ pac_ez; phase_amplitude_coupling(signal)];
		rms_ez = [rms_ez; rms(signal)];
		psd_ez = [psd_ez; pow_spec_den(signal, fs)];
		lyap_exp_ez =[ lyap_exp_ez; lyapunovExponent(signal)];
		corr_dim_ez = [corr_dim_ez; correlationDimension(signal)];
		approx_non_ent_ez = [approx_non_ent_ez; approximateEntropy(signal)];
		
		
		
		clear signal;
		
		 			
 		%graph properties
 		
 		corr_mat = zeros(length(channel_names),length(channel_names));
 		
 		for kk=ez_channels_index
 		
 			for pp=1:length(channel_names)
 			
 			
				%do calculation only for interested channel rows and colums
			
				if (round(ez_Ripples_position1(i) + (1 * fs)) > length(xx1(1,:)))
				 		
				 	end_of_signal_ind = round(ez_Ripples_position1(i)) + 10;
				 					
				else
				 			
					end_of_signal_ind = round(ez_Ripples_position1(i)) + (1 * fs);
				 			
				end
							
				
 				sig1 = xx1(kk, round((ez_Ripples_position1(i)))  : end_of_signal_ind);
 				sig2 = xx1(pp, round((ez_Ripples_position1(i)))  : end_of_signal_ind);
			
						 
				if ( prcorr2(sig1', sig2') > 0.6);
				
					corr_mat(kk,pp) = 1;
					
				else
					corr_mat(kk,pp) = 0;
				
				end
			
			
			end
 		
		end
		
		
 		G = digraph(corr_mat);
 		t1 = indegree(G);
 		t2 = outdegree(G);
 		indeg_ez = [indeg_ez; t1(ch)];
 		outdeg_ez = [outdeg_ez; t2(ch)];
 		totaldeg_ez = [totaldeg_ez; t1(ch)+t2(ch)];
 		t3 = centrality(G ,'betweenness');
 		wbc_ez = [wbc_ez; t3(ch)];
		
		ch_ez = [ch_ez; ez_Ripples_channel1(i)];
		
 		clear G corr_mat;
 
		toc
		strcat('Ripples EZ = ',num2str(i),' out of ', num2str(length(ez_Ripples_channel1)))
		
end
	


	
% Features for non EZ

amplitude_non_ez = [];
pac_non_ez = [];
rms_non_ez = [];
psd_non_ez = [];
lyap_exp_non_ez =[];
corr_dim_non_ez = [];
approx_non_ent_non_ez = [];
indeg_non_ez = [];
outdeg_non_ez = [];
totaldeg_non_ez = [];
wbc_non_ez = [];
ch_non_ez=[];

% generate features
%for i=1:length(non_ez_Ripples_channel1)-5  % total detections iteration

for i=1:length(non_ez_Ripples_channel1)-5  % total detections iteration
    tic
    
	for j=1:length(channel_names)	% finding channel name index
	
		if(strcmp(non_ez_Ripples_channel1(i), channel_names(j)))
	
		ch = j;
	
		end
	end
	
	% prunnig the 1 second signa1
	
	signal = xx1(ch, round((non_ez_Ripples_position1(i))  : round(non_ez_Ripples_position1(i) + (1 * fs))));

	amplitude_non_ez = [amplitude_non_ez; max(signal)];
	pac_non_ez = [ pac_non_ez; phase_amplitude_coupling(signal)];
	rms_non_ez = [rms_non_ez; rms(signal)];
	psd_non_ez = [psd_non_ez; pow_spec_den(signal, fs)];
	lyap_exp_non_ez =[ lyap_exp_non_ez; lyapunovExponent(signal)];
	corr_dim_non_ez = [corr_dim_non_ez; correlationDimension(signal)];
	approx_non_ent_non_ez = [approx_non_ent_non_ez; approximateEntropy(signal)];
	
	
	
 	%graph properties
 		
 		corr_mat = zeros(length(channel_names),length(channel_names));
 		
 		for kk=non_ez_channels_index
 		
 			for pp=non_ez_channels_index
 			
 			
				%do calculation only for interested channel rows and colums
			
				if (round(non_ez_Ripples_position1(i) + (1 * fs)) > length(xx1(1,:)))
				 		
				 	end_of_signal_ind = round(non_ez_Ripples_position1(i)) + 10;
				 					
				else
				 			
					end_of_signal_ind = round(non_ez_Ripples_position1(i)) + (1 * fs);
				 			
				end
							
							
 				sig1 = xx1(kk, round((non_ez_Ripples_position1(i)))  : end_of_signal_ind);
 				sig2 = xx1(pp, round((non_ez_Ripples_position1(i)))  : end_of_signal_ind);
			
						 
				if ( prcorr2(sig1', sig2') > 0.6);
				
					corr_mat(kk,pp) = 1;
					
				else
					corr_mat(kk,pp) = 0;
				
				end
			
			
			end
 		
		end
		
 	G = digraph(corr_mat);
 	t1 = indegree(G);
 	t2 = outdegree(G);
 	indeg_non_ez = [indeg_non_ez; t1(ch)];
 	outdeg_non_ez = [outdeg_non_ez; t2(ch)];
 	totaldeg_non_ez = [totaldeg_non_ez; t1(ch)+t2(ch)];
 	t3 = centrality(G ,'betweenness');
 	wbc_non_ez = [wbc_non_ez; t3(ch)];
	ch_non_ez = [ch_non_ez; non_ez_Ripples_channel1(i)];
 	toc

	strcat('Ripples non EZ = ',num2str(i),' out of ', num2str(length(non_ez_Ripples_channel1)))


end

	
save Ripples_dataset.mat ch_ez ch_non_ez amplitude_ez pac_ez rms_ez psd_ez lyap_exp_ez corr_dim_ez approx_non_ent_ez indeg_ez outdeg_ez totaldeg_ez wbc_ez amplitude_non_ez pac_non_ez rms_non_ez psd_non_ez lyap_exp_non_ez corr_dim_non_ez approx_non_ent_non_ez indeg_non_ez outdeg_non_ez totaldeg_non_ez wbc_non_ez;
	
disp("Ripples completed")



% For Fast Ripples %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




clear xx1;


%load('channel_names.mat');

% Define EZ and non-EZ
%ez_channels = ["H'1-H'2", "H'2-H'3", "H'3-H'4","H'3-H'4"];
%ez_channels_index = [10:13,30:34];

% create vector  of channel index
channel_names_index = [1:length(channel_names)];
   
% determine how many elements is ten percent
numelements = round(non_ez_precen_FR*length(channel_names_index));
% get the randomly-selected indices
indices = randperm(length(channel_names_index));
indices = indices(1:numelements);
% choose the subset of a you want
non_ez_channels_index = indices;
	 	 
% Remove EZ channels from index
% electrode cost
   
for i=ez_channels_index

	non_ez_channels_index(non_ez_channels_index == i) = [];

end

non_ez_channels_index = unique(non_ez_channels_index); 
non_ez_channels = channel_names(non_ez_channels_index);

% extract

%load('HFO_Detections.mat');
%Column 1 indicates the channel in which the
% event was detected, column 2 the frequency, column 3 the start sample,
% column 4 the duration (in samples), column 5 the strenght (against which
% the threshold is compared).

FastRipples_channel_index = FastRipples(:,1);
FastRipples_position1 = FastRipples(:,3);
FastRipples_strength1 = FastRipples(:,5);


ez_FastRipples_position1 = [];
ez_FastRipples_channel1 = [];
	

%extract only EZ and non-EZ channels
for j = 1 : length(ez_channels)

	for i = 1 : length(FastRipples_position1)

		if (strcmp(channel_names(FastRipples_channel_index(i)), ez_channels(j)))
		
			if (FastRipples_strength1(i) > FastRipples_strength)
		
				ez_FastRipples_position1 = [ez_FastRipples_position1;FastRipples_position1(i)];
				ez_FastRipples_channel1 = [ez_FastRipples_channel1;channel_names(FastRipples_channel_index(i))];
				
				
			end
	
		end
	end
end


clear FastRipples


non_ez_FastRipples_position1 = [];
non_ez_FastRipples_channel1 = [];

	

%extract only EZ and non-EZ channels
for j = 1 : length(non_ez_channels)

	for i = 1 : length(FastRipples_position1)

		if (strcmp(channel_names(FastRipples_channel_index(i)), non_ez_channels(j)))
		
			if (FastRipples_strength1(i) > FastRipples_strength)
		
			non_ez_FastRipples_position1 = [non_ez_FastRipples_position1;FastRipples_position1(i)];
			non_ez_FastRipples_channel1 = [non_ez_FastRipples_channel1;channel_names(FastRipples_channel_index(i))];
			
			end
	
		end
	end
end



% Generating data set for FastRipples

load seeg.mat;

% filter seeg for spike dataset
	
%Defining bandpass filter
fc1 = 250; % Cut off frequency

if fs<1100
    
fc2 = 450; % Cut off frequency

else
    
    fc2 = 500; % Cut off frequency
end

[b,a] = butter(6,[fc1,fc2]/(fs/2),'bandpass'); 


wo = 50 / (fs / 2);
bw = wo / 35;
[b1, a1] = iirnotch(wo, bw);
		
		
for i = 1: length(channel_names)


	xx1(i,:) = filter(b1, a1,  xx(i,:));
	xx1(i,:) = filter(b,a,xx1(i,:));

end
	

clear xx;
xx1(:,end:end+2100) = 0;


 amplitude_ez = [];
 pac_ez = [];
 rms_ez = [];
 psd_ez = [];
 lyap_exp_ez =[];
 corr_dim_ez = [];
 approx_non_ent_ez = [];
 indeg_ez = [];
 outdeg_ez = [];
 totaldeg_ez = [];
 wbc_ez = [];
 ch_ez = [];



% generate features
for i=1:length(ez_FastRipples_channel1)-5  % total detections iteration

	tic
	
	for j=1:length(channel_names)	% finding channel name index
	
		if(strcmp(ez_FastRipples_channel1(i), channel_names(j)))
	
		ch = j;
	
		end
	end
	
	% prunnig the 1 second signa1
	
	
	if (round(ez_FastRipples_position1(i) + (1 * fs)) > length(xx1(1,:)))

			end_of_signal_ind = round(ez_FastRipples_position1(i)) + 10;
			
	else
	
			end_of_signal_ind = round(ez_FastRipples_position1(i)) + (1 * fs);
	
	end
			
			
	
	signal = xx1(ch, round((ez_FastRipples_position1(i))) : end_of_signal_ind);

	amplitude_ez = [amplitude_ez; max(signal)];
	pac_ez = [ pac_ez; phase_amplitude_coupling(signal)];
	rms_ez = [rms_ez; rms(signal)];
	psd_ez = [psd_ez; pow_spec_den(signal, fs)];
	lyap_exp_ez =[ lyap_exp_ez; lyapunovExponent(signal)];
	corr_dim_ez = [corr_dim_ez; correlationDimension(signal)];
	approx_non_ent_ez = [approx_non_ent_ez; approximateEntropy(signal)];
	
	
% 	
% 	%graph properties
% 	
		corr_mat = zeros(length(channel_names),length(channel_names));
 		
 		for kk=ez_channels_index
 		
 			for pp=1 : length(channel_names)
 			
 			
				%do calculation only for interested channel rows and colums
			
				if (round(ez_FastRipples_position1(i) + (1 * fs)) > length(xx1(1,:)))
				 		
				 	end_of_signal_ind = round(ez_FastRipples_position1(i)) + 10;
				 					
				else
				 			
					end_of_signal_ind = round(ez_FastRipples_position1(i)) + (1 * fs);
				 			
				end
							
				
 				sig1 = xx1(kk, round((ez_FastRipples_position1(i)))  : end_of_signal_ind);
 				sig2 = xx1(pp, round((ez_FastRipples_position1(i)))  : end_of_signal_ind);
			
						 
				if ( prcorr2(sig1', sig2') > 0.6);
				
					corr_mat(kk,pp) = 1;
					
				else
					corr_mat(kk,pp) = 0;
				
				end
			
			
			end
 		
		end
 	
 	
 
	G = digraph(corr_mat);
 	t1 = indegree(G);
 	t2 = outdegree(G);
 	indeg_ez = [indeg_ez; t1(ch)];
 	outdeg_ez = [outdeg_ez; t2(ch)];
 	totaldeg_ez = [totaldeg_ez; t1(ch)+t2(ch)];
 	t3 = centrality(G ,'betweenness');
 	wbc_ez = [wbc_ez; t3(ch)];
	
	ch_ez = [ch_ez; ez_FastRipples_channel1(i)];
 
 	toc
	strcat('FastRipples EZ = ',num2str(i),' out of ', num2str(length(ez_FastRipples_channel1)))

end
	
		
	% Features for non EZ

	 amplitude_non_ez = [];
	 pac_non_ez = [];
	 rms_non_ez = [];
	 psd_non_ez = [];
	 lyap_exp_non_ez =[];
	 corr_dim_non_ez = [];
	 approx_non_ent_non_ez = [];
	 indeg_non_ez = [];
	 outdeg_non_ez = [];
	 totaldeg_non_ez = [];
	 wbc_non_ez = [];
	 ch_non_ez = [];
		
	% generate features
	for i=1:length(non_ez_FastRipples_channel1)-5  % total detections iteration

		tic

		for j=1:length(channel_names)	% finding channel name index
		
			if(strcmp(non_ez_FastRipples_channel1(i), channel_names(j)))
		
			ch = j;
		
			end
			
		end
		
		% prunnig the 1 second signa1
		
		signal = xx1(ch, round((non_ez_FastRipples_position1(i))  : round(non_ez_FastRipples_position1(i) + (1 * fs))));


		disp("aa")
		amplitude_non_ez = [amplitude_non_ez; max(signal)];
		pac_non_ez = [ pac_non_ez; phase_amplitude_coupling(signal)];
		rms_non_ez = [rms_non_ez; rms(signal)];
		psd_non_ez = [psd_non_ez; pow_spec_den(signal, fs)];
		lyap_exp_non_ez =[ lyap_exp_non_ez; lyapunovExponent(signal, fs)];
		corr_dim_non_ez = [corr_dim_non_ez; correlationDimension(signal)];
		approx_non_ent_non_ez = [approx_non_ent_non_ez; approximateEntropy(signal)];
		
	
		
	% 	%graph properties
		
		corr_mat = zeros(length(channel_names),length(channel_names));
			
			for kk=non_ez_channels_index
			
				for pp=non_ez_channels_index
				
				
					%do calculation only for interested channel rows and colums
				
					if (round(non_ez_FastRipples_position1(i) + (1 * fs)) > length(xx1(1,:)))
							
						end_of_signal_ind = round(non_ez_FastRipples_position1(i)) + 10;
										
					else
								
						end_of_signal_ind = round(non_ez_FastRipples_position1(i)) + (1 * fs);
								
					end
								
								
					sig1 = xx1(kk, round((non_ez_FastRipples_position1(i)))  : end_of_signal_ind);
					sig2 = xx1(pp, round((non_ez_FastRipples_position1(i)))  : end_of_signal_ind);
				
							 
					if ( prcorr2(sig1', sig2') > 0.6);
					
						corr_mat(kk,pp) = 1;
						
					else
						corr_mat(kk,pp) = 0;
					
					end
				
				
				end
			
			end
		
	 
		G = digraph(corr_mat);
		t1 = indegree(G);
		t2 = outdegree(G);
		indeg_non_ez = [indeg_non_ez; t1(ch)];
		outdeg_non_ez = [outdeg_non_ez; t2(ch)];
		totaldeg_non_ez = [totaldeg_non_ez; t1(ch)+t2(ch)];
		t3 = centrality(G ,'betweenness');
		wbc_non_ez = [wbc_non_ez; t3(ch)];
			
	 ch_non_ez = [ch_non_ez; non_ez_FastRipples_channel1(i)];
	 
		
		toc
		strcat('FastRipples non EZ = ',num2str(i),' out of ', num2str(length(non_ez_FastRipples_channel1)))

	end
		
		
	save FastRipples_dataset.mat ch_ez ch_non_ez amplitude_ez pac_ez rms_ez psd_ez lyap_exp_ez corr_dim_ez approx_non_ent_ez indeg_ez outdeg_ez totaldeg_ez wbc_ez amplitude_non_ez pac_non_ez rms_non_ez psd_non_ez lyap_exp_non_ez corr_dim_non_ez approx_non_ent_non_ez indeg_non_ez outdeg_non_ez totaldeg_non_ez wbc_non_ez;
	disp("FastRipples completed")
