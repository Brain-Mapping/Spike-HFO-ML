function [mi] = phase_amplitude_coupling(signal)
    % Phase amplitude coupling
    x = signal; 
    Hx = hilbert(x);
    xphase = angle(Hx); % phase
    xamp = abs(Hx); % amplitude
    mi = modulationIndex(xphase, xamp);
    clear x Hx xphase xamp;
end