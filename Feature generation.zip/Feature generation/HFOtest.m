%HFOtest.m


clearvars -except names

aa = dir('*.edf')

filename=aa.name;


global RippleRate FastRippleRate Ripples FastRipples xx fs channel_names;
batch_run(filename);


function batch_run(filename)

	global RippleRate FastRippleRate Ripples FastRipples xx fs channel_names

	[hdr, xx]  = edfread(filename);

	[data,header,cfg] = lab_read_edf(filename);

	channel_names = cellstr(header.hdr.channelname);

	channel_names = string(channel_names);

	channel_names = channel_names(1:end);




		Ind1 = find(contains(channel_names,'REF'));
		Ind2 = find(contains(channel_names,'Ref'));
		Ind3 = find(contains(channel_names,'ref'));

		if(Ind1)

			channel_count = Ind1;
		end

		if(Ind2)

			channel_count = Ind2;
		end

		if(Ind3)

			channel_count = Ind3;
		end

		channel_count = channel_count-1;
		channel_names = channel_names(1:channel_count);

		xx=xx(1:channel_count,:);

		[channel_names, xx]=bipolar_test(channel_names,xx);


	

	fs=ceil(hdr.frequency(1))

	patient_name = hdr.patientID;

	patient_name = regexp(patient_name, ',', 'split');

	patient_name = char(patient_name{1});
	
	save('seeg.mat', 'xx', '-v7.3')
	
	save channel_names.mat channel_names  fs;


	[RippleRate,FastRippleRate,Ripples,FastRipples] = HFODetector(xx',ceil(fs));

	save('HFO_Detections.mat','Ripples','FastRipples');
	
	disp(" HFO Detection completed")

end

