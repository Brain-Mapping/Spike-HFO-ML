%% H2 Index main function
function[hindex] = h2_corr(xd,yd)
        st = 1; et=floor(length(xd)/10);
        for i = 1:10
            xda{1,i} = xd(st:et);
            yda{1,i} = yd(st:et);
            xdata = (xda{1,i});
            ydata = (yda{1,i});
            st = st+floor(length(xd)/10);
            et = et+floor(length(xd)/10);
            muma = xdata.*ydata;
            muxm = xdata.*xdata;
            % plot(xdata,ydata,'o');
            mx = mean(xdata);
            my = mean(ydata);
            mm = mean(muma);
            mxm = mean(muxm);
            m = ((mx*my)-(mm))/(((mx)^2)-(mxm));
            b = my - (m*mx);
            ydat = (m.*xdata)+b;
            nm(i) = sum((ydata - ydat).^2);
            dm(i) = sum((ydata - my).^2);
        end
hindex = 1-(sum(nm)/sum(dm));

end
